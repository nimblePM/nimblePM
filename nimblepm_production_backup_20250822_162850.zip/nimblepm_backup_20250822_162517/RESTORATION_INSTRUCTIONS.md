# nimblepm.ca Database Backup Restoration Instructions

**Backup Date:** August 22, 2025
**Source:** nimblepm.ca (OpenProject 16 with PostgreSQL 17)
**Database Contents:** Complete production data migrated from nimble.engineer

## Database Statistics
- **Projects:** 215
- **Users:** 158  
- **Work Packages:** 4,014

## Files Included
- `nimblepm_full_backup.sql` - Full PostgreSQL 17 database backup with schema and data
- `docker-compose.stable16.yml` - Docker Compose configuration used
- `env.production` - Environment configuration file
- `RESTORATION_INSTRUCTIONS.md` - This file

## Restoration Methods

### Method 1: PostgreSQL 17 (Recommended)

For PostgreSQL 17 databases:

```bash
# 1. Create database (if not exists)
export PGPASSWORD=your_password
psql -h your_host -p your_port -U your_user -c "CREATE DATABASE openproject;"

# 2. Restore from backup
psql -h your_host -p your_port -U your_user < nimblepm_full_backup.sql
```

### Method 2: OpenProject Docker Compose

1. Place `docker-compose.stable16.yml` and `env.production` in your project directory
2. Update `env.production` with your database connection details
3. Create and restore database:

```bash
# Stop any running services
docker compose -f docker-compose.stable16.yml down

# Create clean database
export PGPASSWORD=your_password
psql -h your_db_host -p your_db_port -U your_user -c "DROP DATABASE IF EXISTS openproject;"
psql -h your_db_host -p your_db_port -U your_user -c "CREATE DATABASE openproject;"

# Restore backup
psql -h your_db_host -p your_db_port -U your_user -d openproject < nimblepm_full_backup.sql

# Start OpenProject services
docker compose -f docker-compose.stable16.yml --env-file env.production up -d
```

### Method 3: PostgreSQL 16 Compatibility

If you need to restore to PostgreSQL 16:

1. Use PostgreSQL 17 tools to restore first:
```bash
# Using PostgreSQL 17 client
docker run --rm -i -e PGPASSWORD=your_password postgres:17 psql -h your_host -p your_port -U your_user < nimblepm_full_backup.sql
```

2. Then dump with PostgreSQL 16 for compatibility:
```bash
# Create PostgreSQL 16 compatible dump
docker run --rm -e PGPASSWORD=your_password postgres:16 pg_dump -h your_host -p your_port -U your_user -d openproject > pg16_backup.sql
```

## Post-Restoration Steps

1. **Run database analysis** (recommended by OpenProject):
```sql
ANALYZE VERBOSE;
```

2. **Start OpenProject services** and verify the data:
```bash
# Check data counts
psql -d openproject -c "SELECT 'Projects' as table_name, COUNT(*) as count FROM projects 
UNION ALL SELECT 'Users', COUNT(*) FROM users 
UNION ALL SELECT 'Work Packages', COUNT(*) FROM work_packages;"
```

3. **Admin Login:**
   - Username: `admin`
   - Password: `NewAdmin123!` (or check your environment configuration)

## Important Notes

- This backup contains the complete production data migrated from nimble.engineer
- The backup was created using OpenProject's recommended PostgreSQL 17 migration procedure
- All data matches exactly: 215 projects, 158 users, 4,014 work packages
- SAML authentication has been disabled in this backup
- The backup includes all file attachments and configuration

## Environment Configuration

Key settings used in `env.production`:
- `DATABASE_URL`: Configure for your target database
- `OPENPROJECT_HOST__NAME`: Set to your domain
- `SECRET_KEY_BASE`: Generate new secret for production use
- `ADMIN_PASSWORD`: Change after restoration

## Troubleshooting

1. **Permission Issues:** Ensure the database user has CREATE, DROP, and all table privileges
2. **Connection Issues:** Verify database host, port, and credentials
3. **Version Conflicts:** Use matching PostgreSQL client version when possible
4. **Large Restore:** The backup is ~38MB and may take several minutes to restore

## Support

This backup was created following OpenProject's official PostgreSQL 17 migration guide:
https://www.openproject.org/docs/installation-and-operations/misc/migration-to-postgresql17/

For additional help, consult OpenProject documentation or the migration guide used.